
require("dotenv").config();

const express = require("express");
const path = require("path");
const session = require("express-session");
const MongoStore = require("connect-mongo").default;

const authRoutes = require("./routes/auth");
const resumeRoutes = require("./routes/resumes");
const connectDB = require("./models/db");
const User = require("./models/User");
const Resume = require("./models/Resume");
const requireAuth = require("./middleware/requireAuth");

const app = express();
const PORT = process.env.PORT || 3000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.use(
  session({
    name: "rsga.sid",
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
      mongoUrl: process.env.MONGO_URI,
      collectionName: "sessions",
      ttl: 86400,
    }),
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 24 * 60 * 60 * 1000,
    },
  })
);

app.use("/", authRoutes);
app.use("/resumes", resumeRoutes);

app.get("/", (req, res) => {
  res.redirect("/register");
});

app.get("/dashboard", requireAuth, async (req, res) => {
  try {
    const user = await User.findById(req.session.userId);

    if (!user) {
      return req.session.destroy(() => {
        res.clearCookie("rsga.sid");
        res.redirect("/login");
      });
    }

    const resumes = await Resume.find({
      user: user._id,
    }).sort({ createdAt: -1 });

    res.render("profile/dashboard", { user, resumes });
  } catch (error) {
    console.error("Dashboard error:", error.message);
    res.status(500).send("Unable to load dashboard.");
  }
});

app.post("/logout", requireAuth, (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      console.error("Logout error:", error.message);
      return res.status(500).send("Unable to log out.");
    }

    res.clearCookie("rsga.sid");
    res.redirect("/login");
  });
});

async function startServer() {
  try {
    if (!process.env.MONGO_URI || !process.env.SESSION_SECRET) {
      throw new Error("MONGO_URI and SESSION_SECRET must be set in .env");
    }

    await connectDB();

    app.listen(PORT, () => {
      console.log(`Server running at http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error("Server startup failed:", error.message);
    process.exit(1);
  }
}

startServer();
