// Run: node seed/seedJobRoles.js   (needs MONGO_URI in .env)
require("dotenv").config();
const mongoose = require("mongoose");
const JobRole = require("../models/JobRole");

const s = (name, importance, learningTimeWeeks, prerequisites = []) => ({
  name, importance, learningTimeWeeks, prerequisites,
});

const roles = [
  {
    name: "Backend Developer", domain: "Software",
    description: "Builds server-side logic, APIs and databases.",
    requiredSkills: [
      s("JavaScript", "High", 4), s("Node.js", "High", 3, ["JavaScript"]),
      s("Express", "High", 2, ["Node.js"]), s("MongoDB", "High", 3),
      s("SQL", "Medium", 3), s("REST APIs", "High", 2), s("Git", "Medium", 1),
      s("Docker", "Low", 2), s("JWT Authentication", "Medium", 2, ["Express"]),
    ],
  },
  {
    name: "Data Analyst", domain: "Data",
    description: "Turns data into insights and reports.",
    requiredSkills: [
      s("SQL", "High", 3), s("Excel", "High", 2), s("Python", "High", 4),
      s("Pandas", "Medium", 2, ["Python"]), s("Statistics", "High", 4),
      s("Data Visualization", "Medium", 2), s("Power BI", "Low", 2), s("Tableau", "Low", 2),
    ],
  },
  {
    name: "Cybersecurity Analyst", domain: "Security",
    description: "Protects systems and detects threats.",
    requiredSkills: [
      s("Networking", "High", 4), s("Linux", "High", 3), s("Cryptography", "Medium", 3),
      s("Penetration Testing", "Medium", 5, ["Networking", "Linux"]),
      s("SIEM Tools", "Medium", 3), s("Python", "Low", 3),
      s("Incident Response", "High", 3), s("Risk Assessment", "Low", 2),
    ],
  },
  {
    name: "Frontend Developer", domain: "Software",
    description: "Builds user interfaces for the web.",
    requiredSkills: [
      s("HTML", "High", 1), s("CSS", "High", 2), s("JavaScript", "High", 4),
      s("React", "High", 4, ["JavaScript"]), s("Git", "Medium", 1),
      s("Responsive Design", "Medium", 1), s("REST APIs", "Medium", 2),
    ],
  },
];

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await JobRole.deleteMany({});
  await JobRole.insertMany(roles);
  console.log(`Seeded ${roles.length} job roles`);
  await mongoose.disconnect();
})();
