require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());
app.use("/api/jobroles", require("./routes/jobRoles"));
app.use("/api/analyze", require("./routes/analyze"));
mongoose.connect(process.env.MONGO_URI)
  .then(() => app.listen(5001, () => console.log("Server running on port 5001")))
  .catch((e) => console.error("Database error:", e.message));
